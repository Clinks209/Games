let canvas = document.getElementById("canvas")
/**@type {CanvasRenderingContext2D}*/
let ctx = canvas.getContext("2d")

ctx.font = "28px Arial"


let width = canvas.width
let height = canvas.height

let brickWidth = 60
let brickHeight = 15
let padWidth = 130
let padHeight = 23
let ballSize = 8
let counter=0
let total=0

let bricks = []

let limits = {
    left: 0 + ballSize,
    right: width - ballSize,
    top: 0 + ballSize,
    bottom: height - 50 - ballSize
}

let mouse = {
    x: 950,
    y: 0
}

let ball = {
    x: 750,
    y: 350,
    velocity: {
        x: 5,
        y: 5
    }
}

canvas.addEventListener("mousemove", onMouse)

function onMouse(event) {
    mouse.x = event.offsetX
    mouse.y = event.offsetY
    pad(mouse.x)
}

function brick(x, y, color) {
    ctx.fillStyle = color
    ctx.fillRect(x, y, brickWidth, brickHeight)
}


function rect(x, y, color) {
    ctx.fillStyle = color
    ctx.fillRect(x, y, brickWidth, brickHeight)
}

function pad(x, y) {
    ctx.fillStyle = "black"
    ctx.fillRect(x - padWidth /2 , 850, padWidth, padHeight)
    
}

function drawBall(x, y) {
    ctx.fillStyle = "red"
    ctx.beginPath()
    ctx.moveTo(x, y)
    ctx.arc(x, y, ballSize, 0, 360)
    ctx.closePath()
    ctx.fill()
}

function clear() {
    ctx.clearRect(0, 0, 1900, 900)
}

function render() {
    clear()
    for (let b of bricks) {
        if (b.live == false) {
            continue
        }  
        brick(b.x, b.y, "blue")
    }
    pad(mouse.x)
    drawBall(ball.x, ball.y)
}

function tick() {
    ball.x += ball.velocity.x
    ball.y += ball.velocity.y

    if ((ball.x > limits.right && ball.velocity.x > 0) || (ball.x < limits.left && ball.velocity.x < 0)) {
        ball.velocity.x *= -1
        
    }
    if (ball.y < limits.top && ball.velocity.y < 0) {
        ball.velocity.y *= -1
        
    }
    if ((ball.y > limits.bottom && ball.velocity.y > 0)
        && (ball.y <= limits.bottom + ballSize)
        && (ball.x >= mouse.x - padWidth / 2 - ballSize)
        && (ball.x <= mouse.x + padWidth / 2 + ballSize)) {
        ball.velocity.y *= -1
        
    }
    for (let b of bricks) {
        if (b.live == false) {
            continue
        }
        checkBrick(b)
        

    }
}

function checkBrick(b) {
    if ((ball.x + ballSize > b.x)
        && (ball.x - ballSize < b.x + brickWidth)
        && (ball.y + ballSize > b.y)
        && ball.y - ballSize < b.y + brickHeight) {
        b.live = false
        counter++
        total--


        if (ball.x < b.x && ball.velocity.x > 0) {
            ball.velocity.x *= -1
        } else if (ball.x > b.x + brickWidth && ball.velocity.x < 0) {
            ball.velocity.x *= -1
        }
        if (ball.x < b.x && ball.velocity.x > 0) {
            ball.velocity.x *= -1
        } else if (ball.x > b.x + brickWidth && ball.velocity.x > 0) {
            ball.velocity.x *= -1
        }

        if (ball.y < b.y && ball.velocity.y > 0) {
            ball.velocity.y *= -1
        } else if (ball.y > b.y + brickHeight && ball.velocity.x < 0) {
            ball.velocity.y *= -1
        }
        if (ball.y < b.y && ball.velocity.y > 0) {
            ball.velocity.y *= -1
        } else if (ball.y > b.y + brickHeight && ball.velocity.x > 0) {
            ball.velocity.y *= -1
        }
    }
}


let lastTime = 0
let delta = 0

function main(time) {
    delta += time - lastTime
    lastTime = time

    if (delta > 1000) {
        delta = 20
    }

    while (delta >= 20) {
        delta -= 20
        tick()
    }
    if(ball.y>height){
      alert ( `        "YOU LOST !!!        Current score: ${counter}        Refresh Page to Retry"`)
    }

    if(total==0){
        alert (`       "CONGRATULATIONS !!!       You have comepleted the Game   :) "`)
    }

    render()

    ctx.fillText(time.textStyle = "", 20, 20)
    ctx.fillStyle = "black" 
    ctx.font=" 40px bold"
    ctx.fillText("Brick Destroyer" , 830,40)
    ctx.font=" 25px itallic"
    ctx.fillText(`Remaining: ${total}` , 1730,30)

    requestAnimationFrame(main)
}

function start() {
    for (let row = 0; row < 8; row++) {
        for (let col = 0; col < 24; col++) {
            total++
            bricks.push({
                x: col * brickWidth * 1.305 + 21,
                y: row * brickHeight * 2 + 80,
                live: true
            })
        }
    }
    requestAnimationFrame(main)
}
start()